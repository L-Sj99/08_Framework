package com.kh.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntegrationReview1Application {

	public static void main(String[] args) {
		SpringApplication.run(IntegrationReview1Application.class, args);
	}

}

package com.kh.test.mapper;

public interface EmployeeMapper {

}

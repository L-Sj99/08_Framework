package com.kh.test.service;

public interface EmployeeService {

}

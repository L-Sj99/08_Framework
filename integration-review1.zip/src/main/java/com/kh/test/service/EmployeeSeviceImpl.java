package com.kh.test.service;

public class EmployeeSeviceImpl implements EmployeeService{

}

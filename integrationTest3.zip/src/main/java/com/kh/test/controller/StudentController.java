package com.kh.test.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kh.test.dto.Student;
import com.kh.test.service.StudentService;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
@RequestMapping("student")
public class StudentController {
	
	private StudentService service;
	
	@GetMapping("selectAllList")
	public List<Student> selectAllList() {
		return service.selectAllList();
	}
	
}
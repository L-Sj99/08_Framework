package com.kh.test.service;

import java.util.List;

import com.kh.test.dto.Student;

public interface StudentService {

	List<Student> selectAllList();

}

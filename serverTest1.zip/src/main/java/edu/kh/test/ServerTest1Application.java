package edu.kh.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServerTest1Application {

	public static void main(String[] args) {
		SpringApplication.run(ServerTest1Application.class, args);
	}

}
